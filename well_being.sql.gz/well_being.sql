-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2022 at 06:15 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `well_being`
--

-- --------------------------------------------------------

--
-- Table structure for table `bma_table`
--

CREATE TABLE `bma_table` (
  `serial` int(11) NOT NULL,
  `bmano` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bma_table`
--

INSERT INTO `bma_table` (`serial`, `bmano`) VALUES
(1, '54321'),
(2, '12345'),
(3, '13579'),
(4, '23456');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_registration`
--

CREATE TABLE `doctor_registration` (
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `speciality` varchar(30) NOT NULL,
  `designation` varchar(30) NOT NULL,
  `nid` varchar(30) NOT NULL,
  `bma` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `blood` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `district` varchar(30) NOT NULL,
  `thana` varchar(30) NOT NULL,
  `area` varchar(30) NOT NULL,
  `buildingno` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor_registration`
--

INSERT INTO `doctor_registration` (`fname`, `lname`, `email`, `mobile`, `speciality`, `designation`, `nid`, `bma`, `dob`, `blood`, `gender`, `picture`, `district`, `thana`, `area`, `buildingno`, `password`) VALUES
('Saleh', 'Nayeem', 'nayeemsaleh@gmail.com', '01671642420', 'Medicine', 'Junior Resident', '5678943216', '12345', '1992-10-20', 'B(+)', 'Male', 'nayeem.jpg', 'Dhaka', 'Jatrabari', 'Mirhazirbagh', '458', '1'),
('Najmin', 'Akter', 'najminakter@gmail.com', '01521445109', 'Gynecologist ', 'Senior Resident', '9876543219', '54321', '1994-05-13', 'O(+)', 'Female', 'najmin.jpg', 'Dhaka', 'Jatrabari', 'Mirhazirbagh', '458', '1');

-- --------------------------------------------------------

--
-- Table structure for table `patient_registration`
--

CREATE TABLE `patient_registration` (
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `patientid` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `nid` varchar(30) NOT NULL,
  `bcn` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(30) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `district` varchar(30) NOT NULL,
  `thana` varchar(30) NOT NULL,
  `area` varchar(30) NOT NULL,
  `buildingno` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `blood` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient_registration`
--

INSERT INTO `patient_registration` (`fname`, `lname`, `patientid`, `email`, `mobile`, `nid`, `bcn`, `dob`, `gender`, `picture`, `district`, `thana`, `area`, `buildingno`, `password`, `blood`) VALUES
('Nuren', 'Abha', '20220920195421', 'nurenabha@gmail.com', '01535447024', '7657890984', '98767545436785325', '1997-11-04', 'Female', 'nuren.jpg', 'Dhaka', 'Jatrabari', 'Mirhazirbagh', '458', '12', 'O(+)'),
('Fahim', 'Faysal', '20220920214849', 'ffnasif@gmail.com', '01521431178', '8765436789', '98765412345678987', '1997-03-24', 'Male', 'fahim.jpg', 'Dhaka', 'Jatrabari', 'Mirhazirbagh', '458', '12', 'O(+)');

-- --------------------------------------------------------

--
-- Table structure for table `prescribe_table`
--

CREATE TABLE `prescribe_table` (
  `serial` int(11) NOT NULL,
  `doctorname` varchar(30) NOT NULL,
  `patientid` varchar(30) NOT NULL,
  `diseasename` varchar(40) NOT NULL,
  `solution` varchar(255) NOT NULL,
  `medicine` varchar(255) NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prescribe_table`
--

INSERT INTO `prescribe_table` (`serial`, `doctorname`, `patientid`, `diseasename`, `solution`, `medicine`, `date`) VALUES
(2, 'Najmin Akter', '20220920214849', 'Cold fiver', 'Stay hydrated. Water, juice, clear broth or warm lemon water with honey helps loosen congestion and prevents dehydration', 'Acetaminophen (Tylenol) and ibuprofen (Advil, Motrin).', '2022-09-21, 19:43'),
(3, 'Najmin Akter', '20220920195421', 'Fiver', 'Stay hydrated. Water, juice, clear broth or warm lemon water with honey helps loosen congestion and prevents dehydration', 'Acetaminophen (Tylenol) and ibuprofen (Advil, Motrin).', '2022-09-21, 19:57');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `serial` int(11) NOT NULL,
  `bma` varchar(30) NOT NULL,
  `place` varchar(100) NOT NULL,
  `weekdays` varchar(30) NOT NULL,
  `time` varchar(39) NOT NULL,
  `fee` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`serial`, `bma`, `place`, `weekdays`, `time`, `fee`) VALUES
(1, '54321', 'Kumudini Medical College', 'saturday, wednesday', '08:00am-11:00am', '600'),
(2, '12345', 'Tangail Medical College', 'sunday, monday', '08:00pm - 11:00pm', '1000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bma_table`
--
ALTER TABLE `bma_table`
  ADD PRIMARY KEY (`serial`);

--
-- Indexes for table `doctor_registration`
--
ALTER TABLE `doctor_registration`
  ADD PRIMARY KEY (`bma`);

--
-- Indexes for table `patient_registration`
--
ALTER TABLE `patient_registration`
  ADD PRIMARY KEY (`patientid`);

--
-- Indexes for table `prescribe_table`
--
ALTER TABLE `prescribe_table`
  ADD PRIMARY KEY (`serial`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`serial`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bma_table`
--
ALTER TABLE `bma_table`
  MODIFY `serial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `prescribe_table`
--
ALTER TABLE `prescribe_table`
  MODIFY `serial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `serial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
